package hust.soict.dsai.aims.media;

public class DigitalVideoDisc extends Disc implements Playable {
    private static int nbDigitalVideoDiscs = 0; 


    public DigitalVideoDisc() {
    	
    }

	@Override
	public void play() throws PlayerException
    {
        if(this.getLength()>0)
        {   
        System.out.println("Playing DVD: " + this.getTitle());
        System.out.println("DVD length: " + this.getLength());
        }
        else
        {
            throw new PlayerException("ERROR: DVD length is non-positive!");
        }
    }

    

}
