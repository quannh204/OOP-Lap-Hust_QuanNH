package hust.soict.dsai.aims.media;

public class Track implements Playable {
    private String title;
    private int length;

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public int getLength() {
        return length;
    }

    public void setLegth(int length) {
        this.length = length;
    }

    public Track(String title, int length) {
        super();
        this.title = title;
        this.length = length;
    }

    @Override
    public void play() throws PlayerException
    {  if(this.getLength()>0)
            {
                System.out.println("Playing Track: " + this.getTitle());
                System.out.println("Track length: " + this.getLength());
            }else
            {
                throw new PlayerException("ERROR: Track length is non-positive!");
            }
    }

    @Override
    public boolean equals(Object o) {
        Track track = (Track) o;
        return this.title.equals(track.title) && this.length == track.length;
    }
}
